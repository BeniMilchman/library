

class loan:
    def __init__(self, book_title, book_type, CusID, BookID, loandate, returndate):
        self.book_title = book_title
        self.book_type = book_type
        self.CusID = CusID
        self.BookID = BookID
        self.loandate = loandate 
        self.returndate = returndate   