


class Book:
    def __init__(self, title, BookID, author, year, type):
        self.title = title
        self.BookID = BookID
        self.author = author
        self.year = year
        self.type = type

